Object.defineProperty(window, 'Shaffl', {
    __proto__: null,
    value: {}
});
Object.defineProperty(window.Shaffl, 'v', {
    value: "0.0.1.5.5-pre",
    enumerable: false,
    configurable: false,
    writable: false
});
Object.defineProperty(window.Shaffl, 'v_full', {
    value: "0.0.1.5.5-pre (Mobile Edition)",
    enumerable: false,
    configurable: false,
    writable: false
});
Object.defineProperty(window.Shaffl, 'licensed_to', {
    value: navigator.vendor,
    enumerable: false,
    configurable: false,
    writable: false
});