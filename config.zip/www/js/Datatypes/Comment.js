class Comment {
	constructor(author, time, content) {
		this.author = author;
		this.time = time;
		this.content = content;
	}
}