class Tag {
	constructor(name) {
		this.name = name;
	}
	getUrl() {
	    return null;
    }
}