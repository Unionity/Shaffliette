class Art {
	constructor(id, url, thumbUrl, pools, rating, comments, tags) {
		this.id = id;
		this.url = url;
		this.thumbUrl = thumbUrl;
		this.pools = pools;
		this.rating = rating;
		this.comments = comments;
		this.tags = tags;
	}
}